-- phpMyAdmin SQL Dump
-- version 4.0.4.1
-- http://www.phpmyadmin.net
--
-- Host: 127.0.0.1
-- Generation Time: Feb 04, 2024 at 06:13 AM
-- Server version: 5.5.32
-- PHP Version: 5.4.19

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- Database: `eventstore`
--
CREATE DATABASE IF NOT EXISTS `eventstore` DEFAULT CHARACTER SET latin1 COLLATE latin1_swedish_ci;
USE `eventstore`;

-- --------------------------------------------------------

--
-- Table structure for table `assigndelboys`
--

CREATE TABLE IF NOT EXISTS `assigndelboys` (
  `id` int(10) NOT NULL AUTO_INCREMENT,
  `assignkey` char(8) NOT NULL,
  `cartid` varchar(11) NOT NULL,
  `loginid` int(11) NOT NULL,
  `currentdate` date NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=7 ;

--
-- Dumping data for table `assigndelboys`
--

INSERT INTO `assigndelboys` (`id`, `assignkey`, `cartid`, `loginid`, `currentdate`) VALUES
(1, 'd2fa5820', '70', 38, '2023-10-17'),
(2, '0ac6a7f4', '72', 38, '2023-10-17'),
(3, '2e1e846f', '71', 38, '2023-10-17'),
(4, 'c38bfedf', '70', 38, '2023-10-17'),
(5, 'b0032f5a', '70', 38, '2023-10-17'),
(6, 'da4d7b5f', '73', 38, '2023-10-17');

-- --------------------------------------------------------

--
-- Table structure for table `bank`
--

CREATE TABLE IF NOT EXISTS `bank` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `accountno` varchar(15) NOT NULL,
  `holdername` varchar(20) NOT NULL,
  `bankname` varchar(20) NOT NULL,
  `branchname` varchar(20) NOT NULL,
  `ifsc` varchar(11) NOT NULL,
  `cardno` varchar(12) NOT NULL,
  `cvv` int(3) NOT NULL,
  `edate` date NOT NULL,
  `tamount` varchar(7) NOT NULL,
  `contactno` varchar(12) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=11 ;

--
-- Dumping data for table `bank`
--

INSERT INTO `bank` (`id`, `accountno`, `holdername`, `bankname`, `branchname`, `ifsc`, `cardno`, `cvv`, `edate`, `tamount`, `contactno`) VALUES
(1, '11233244565', 'Aisha', 'SBI', 'Vamanapuram', '123456789', '222622282229', 213, '2026-11-13', '1842705', '0906785430'),
(2, '44577899865', 'Aleena', 'Federal Bank', 'Kilimanoor', '101112131', '444544464448', 546, '2026-11-13', '2489930', '985632147'),
(3, '88599877825', 'Arya', 'union', 'vattapara', '141516171', '111511151115', 789, '2026-03-19', '4999360', '8597456512'),
(5, '12345678988', 'Alex', 'SBI', 'Trivandrum', '181920212', '222522252225', 213, '2026-11-13', '2476000', '7485963212'),
(9, '25236571982', 'Variety', 'Federal Bank', 'Punaloor', '2591736482', '333666659998', 998, '2027-05-01', '2617635', '0906785435'),
(10, '65285456235', 'f2fashion', 'SBI', 'ponganadu', '5432985432', '875412306920', 897, '2027-05-01', '1090508', '8589917005');

-- --------------------------------------------------------

--
-- Table structure for table `cart`
--

CREATE TABLE IF NOT EXISTS `cart` (
  `id` int(10) NOT NULL AUTO_INCREMENT,
  `cartkey` char(8) NOT NULL,
  `loginid` int(11) NOT NULL,
  `menuid` int(11) NOT NULL,
  `currentdate` date NOT NULL,
  `quantity` int(20) NOT NULL,
  `totalamount` int(20) NOT NULL,
  `paymentstatus` int(1) NOT NULL,
  `delstatus` int(1) NOT NULL,
  `returnstatus` int(1) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=77 ;

--
-- Dumping data for table `cart`
--

INSERT INTO `cart` (`id`, `cartkey`, `loginid`, `menuid`, `currentdate`, `quantity`, `totalamount`, `paymentstatus`, `delstatus`, `returnstatus`) VALUES
(59, '998f5ef2', 5, 19, '2023-10-13', 1, 10000, 1, 1, 1),
(61, '90bae6fd', 5, 0, '2023-10-14', 2, 0, 0, 0, 0),
(62, '721f7798', 5, 22, '2023-10-14', 2, 24000, 1, 1, 0),
(63, '81f8d363', 5, 20, '2023-10-14', 2, 10000, 1, 1, 0),
(65, 'c3baa083', 5, 20, '2023-10-14', 2, 10000, 1, 1, 0),
(66, '4f98fb4a', 5, 0, '2023-10-14', 2, 0, 0, 0, 0),
(67, 'bb90efa7', 5, 19, '2023-10-16', 2, 20000, 1, 1, 1),
(68, 'f64feba8', 5, 24, '2023-10-17', 2, 17000, 1, 0, 0),
(69, '4d5ec134', 5, 24, '2023-10-17', 1, 8500, 1, 0, 0),
(70, '0cd2ed46', 5, 23, '2023-10-17', 2, 20000, 1, 1, 1),
(71, '64f99afd', 5, 25, '2023-10-17', 1, 5000, 1, 1, 0),
(72, 'db6d166e', 5, 25, '2023-10-17', 2, 10000, 1, 1, 0),
(73, 'de6af829', 5, 22, '2023-10-17', 2, 24000, 1, 1, 0),
(74, '11199206', 5, 20, '2024-02-01', 1, 5000, 0, 0, 0),
(75, '49f02273', 5, 26, '2024-02-01', 1, 2500, 0, 0, 0),
(76, '3ae48440', 5, 19, '2024-02-03', 0, 10000, 0, 0, 0);

-- --------------------------------------------------------

--
-- Table structure for table `complaints`
--

CREATE TABLE IF NOT EXISTS `complaints` (
  `id` int(10) NOT NULL AUTO_INCREMENT,
  `compkey` char(8) NOT NULL,
  `complaint` varchar(60) NOT NULL,
  `productid` int(11) NOT NULL,
  `loginid` int(11) NOT NULL,
  `currentdate` date NOT NULL,
  `adreply` varchar(60) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=6 ;

--
-- Dumping data for table `complaints`
--

INSERT INTO `complaints` (`id`, `compkey`, `complaint`, `productid`, `loginid`, `currentdate`, `adreply`) VALUES
(1, '902e5841', 'product is not good and damaged', 0, 5, '2023-10-13', ''),
(3, 'fcf732e3', 'damaged', 15, 5, '2023-10-13', 'aa'),
(4, 'dfd8b82d', 'j', 19, 5, '2023-10-13', ''),
(5, '896110a0', 'Bad', 23, 5, '2023-10-17', 'replacement will get to you');

-- --------------------------------------------------------

--
-- Table structure for table `customer`
--

CREATE TABLE IF NOT EXISTS `customer` (
  `id` int(10) NOT NULL AUTO_INCREMENT,
  `ckey` char(8) NOT NULL,
  `customername` varchar(20) NOT NULL,
  `address` varchar(60) NOT NULL,
  `contact` varchar(12) NOT NULL,
  `loginid` int(11) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=14 ;

--
-- Dumping data for table `customer`
--

INSERT INTO `customer` (`id`, `ckey`, `customername`, `address`, `contact`, `loginid`) VALUES
(2, 'a9c7bbb8', 'customer', 'customer', '0906785430', 5),
(3, '466c1e43', 'customer2', 'aaa', '6558746864', 6);

-- --------------------------------------------------------

--
-- Table structure for table `deliveryboy`
--

CREATE TABLE IF NOT EXISTS `deliveryboy` (
  `id` int(10) NOT NULL AUTO_INCREMENT,
  `delkey` char(8) NOT NULL,
  `delname` varchar(20) NOT NULL,
  `address` varchar(60) NOT NULL,
  `pincode` varchar(6) NOT NULL,
  `district` varchar(20) NOT NULL,
  `city` varchar(20) NOT NULL,
  `contactno` varchar(12) NOT NULL,
  `loginid` int(11) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=9 ;

--
-- Dumping data for table `deliveryboy`
--

INSERT INTO `deliveryboy` (`id`, `delkey`, `delname`, `address`, `pincode`, `district`, `city`, `contactno`, `loginid`) VALUES
(8, '0e431975', 'Delivery Team', 'Delivery Team,Trivandrum', '695607', 'Trivandrum', 'Trivandrum', '09856253645', 38);

-- --------------------------------------------------------

--
-- Table structure for table `feedback`
--

CREATE TABLE IF NOT EXISTS `feedback` (
  `id` int(10) NOT NULL AUTO_INCREMENT,
  `feedkey` char(8) NOT NULL,
  `feedback` varchar(60) NOT NULL,
  `productid` int(11) NOT NULL,
  `loginid` int(11) NOT NULL,
  `currentdate` date NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=12 ;

--
-- Dumping data for table `feedback`
--

INSERT INTO `feedback` (`id`, `feedkey`, `feedback`, `productid`, `loginid`, `currentdate`) VALUES
(1, '8e411a0c', 'ssss', 11, 5, '2023-05-08'),
(2, '8b79f343', 'hjhhkjh', 11, 5, '2023-05-08'),
(3, '81201ed2', '444', 0, 5, '2023-05-28'),
(4, 'a154c3fe', 'bad product', 0, 5, '2023-10-13'),
(5, '6a3369aa', 'bad product', 59, 5, '2023-10-13'),
(6, '094f4711', 'bad product', 0, 5, '2023-10-13'),
(7, '5250329d', 'bad product', 19, 5, '2023-10-13'),
(8, 'e2f0620a', 'bad product', 19, 5, '2023-10-13'),
(9, '642d3ee8', 'fee', 19, 5, '2023-10-13'),
(10, '0df88924', 'good', 19, 5, '2023-10-16'),
(11, '1bbdd55a', 'bad', 23, 5, '2023-10-17');

-- --------------------------------------------------------

--
-- Table structure for table `login`
--

CREATE TABLE IF NOT EXISTS `login` (
  `id` int(10) NOT NULL AUTO_INCREMENT,
  `lkey` char(8) NOT NULL,
  `email` varchar(32) NOT NULL,
  `password` varchar(32) NOT NULL,
  `status` enum('0','1','2') NOT NULL,
  `usertype` enum('0','1','2','3') NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=39 ;

--
-- Dumping data for table `login`
--

INSERT INTO `login` (`id`, `lkey`, `email`, `password`, `status`, `usertype`) VALUES
(5, '6db0e81a', 'customer@gmail.com', '202cb962ac59075b964b07152d234b70', '1', '2'),
(27, 'b796565a', 'shop@gmail.com', '202cb962ac59075b964b07152d234b70', '1', '1'),
(28, 'b24bc109', 'shop1@gmail.com', '202cb962ac59075b964b07152d234b70', '1', '1'),
(30, 'fce59282', 'mithun@gmail.com', '202cb962ac59075b964b07152d234b70', '1', '3'),
(32, 'ae85f11e', 'kallar@gmail.com', '202cb962ac59075b964b07152d234b70', '2', '1'),
(33, '736d38e7', 'admin@gmail.com', '202cb962ac59075b964b07152d234b70', '1', '0'),
(34, '75b14159', 'jj@gmail.com', '202cb962ac59075b964b07152d234b70', '1', '3'),
(35, '504ea27a', 't20store@gmail.com', '202cb962ac59075b964b07152d234b70', '1', '1'),
(36, 'd2ad23c6', 'noel123@gmail.com', '202cb962ac59075b964b07152d234b70', '1', '2'),
(37, 'fca26c57', 'ajmibismi@gmail.com', '202cb962ac59075b964b07152d234b70', '1', '1'),
(38, '9f9e416f', 'delivery@gmail.com', '202cb962ac59075b964b07152d234b70', '1', '3');

-- --------------------------------------------------------

--
-- Table structure for table `offers`
--

CREATE TABLE IF NOT EXISTS `offers` (
  `id` int(10) NOT NULL AUTO_INCREMENT,
  `offkey` char(8) NOT NULL,
  `productid` int(10) NOT NULL,
  `offers` varchar(60) NOT NULL,
  `loginid` int(10) NOT NULL,
  `currentdate` date NOT NULL,
  `offerlimit` int(11) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=6 ;

--
-- Dumping data for table `offers`
--

INSERT INTO `offers` (`id`, `offkey`, `productid`, `offers`, `loginid`, `currentdate`, `offerlimit`) VALUES
(4, '156fc659', 11, '90', 1, '2023-05-13', 60),
(5, '65fa2627', 24, '50% off', 28, '2023-10-13', 5);

-- --------------------------------------------------------

--
-- Table structure for table `payment`
--

CREATE TABLE IF NOT EXISTS `payment` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `pykey` char(8) NOT NULL,
  `cowner` varchar(20) NOT NULL,
  `card` int(12) NOT NULL,
  `cvv` int(3) NOT NULL,
  `edate` date NOT NULL,
  `loginid` int(11) NOT NULL,
  `cdate` date NOT NULL,
  `amount` int(7) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=84 ;

--
-- Dumping data for table `payment`
--

INSERT INTO `payment` (`id`, `pykey`, `cowner`, `card`, `cvv`, `edate`, `loginid`, `cdate`, `amount`) VALUES
(31, 'b204e5dd', 'Aleem', 2147483647, 222, '2026-11-13', 5, '2023-04-27', 1500),
(32, 'fba0219a', 'Aleem', 2147483647, 213, '2026-11-13', 5, '2023-05-06', 0),
(33, 'b62bdafc', 'Aleem', 2147483647, 213, '2026-11-13', 5, '2023-05-06', 37500),
(34, 'e3b753d9', 'Aleem', 2147483647, 213, '2026-11-13', 5, '2023-05-06', 0),
(35, 'd8d0d451', 'Aleem', 2147483647, 213, '2026-11-13', 5, '2023-05-06', 7500),
(36, '2d31cd05', 'Aleem', 2147483647, 213, '2026-11-13', 5, '2023-05-06', 750),
(37, '4d58c9f7', 'Aleem', 2147483647, 213, '2026-11-13', 5, '2023-05-06', 750),
(38, '38aaa3cd', 'Aleem', 2147483647, 213, '2026-11-13', 5, '2023-05-06', 0),
(39, 'a235af61', 'Aleem', 2147483647, 213, '2026-11-13', 5, '2023-05-06', 37500),
(40, 'c42fcd01', 'Aleem', 2147483647, 213, '2026-11-13', 5, '2023-05-06', 37500),
(41, '72cb5e1a', 'Aleem', 2147483647, 213, '2026-11-13', 5, '2023-05-06', 750),
(42, 'bcf265c7', 'Aleem', 2147483647, 213, '2026-11-13', 5, '2023-05-06', 750),
(43, '4a41bf20', 'Aleem', 2147483647, 213, '2026-11-13', 5, '2023-05-06', 750),
(44, '9fb4b51c', 'Aleem', 2147483647, 213, '2026-11-13', 5, '2023-05-06', 750),
(45, '6097d707', 'Aleem', 2147483647, 213, '2026-11-13', 5, '2023-05-07', 2250),
(46, '894ac04c', 'Aleem', 2147483647, 213, '2026-11-13', 5, '2023-05-07', 3000),
(47, '8fb91d37', 'Aleem', 2147483647, 213, '2026-11-13', 5, '2023-05-08', 0),
(48, '324c2ad8', 'Variety', 2147483647, 998, '2027-05-01', 1, '2023-05-20', 750),
(49, '500027eb', 'Variety', 2147483647, 998, '2027-05-01', 1, '2023-05-20', 750),
(50, '4c4d62ed', 'Variety', 2147483647, 998, '2027-05-01', 1, '2023-05-20', 750),
(51, 'affb22f0', 'Variety', 2147483647, 998, '2027-05-01', 1, '2023-05-20', 750),
(52, '4e4e0b91', 'Variety', 2147483647, 998, '2027-05-01', 1, '2023-05-20', 750),
(53, '9c4d3050', 'Midhun', 2147483647, 546, '0000-00-00', 1, '2023-05-20', 750),
(54, 'db4b28ed', 'Aleem', 2147483647, 213, '2026-11-13', 5, '2023-05-28', 3750),
(55, '71f5fffa', 'Aleem', 2147483647, 213, '2026-11-13', 5, '2023-07-07', 1000),
(56, '1322330e', 'Midhun', 2147483647, 213, '2026-11-13', 5, '2023-07-08', 2000),
(57, 'fcbc48f7', 'Midhun', 2147483647, 546, '0000-00-00', 5, '2023-07-08', 6400),
(58, 'c005257a', 'Aleem', 2147483647, 213, '2026-11-13', 5, '2023-07-08', 2000),
(59, '32374cb9', 'Aleem', 2147483647, 213, '2026-11-13', 5, '2023-07-08', 2000),
(60, '0e938652', 'Aleem', 2147483647, 213, '2026-11-13', 5, '2023-07-08', 6400),
(61, '9a7bbe3b', 'Aleem', 2147483647, 213, '2026-11-13', 5, '2023-07-08', 2000),
(62, 'b43c2229', 'Aleem', 2147483647, 213, '2026-11-13', 5, '2023-07-19', 12800),
(63, '7b5f34a0', 'Midhun', 2147483647, 546, '2026-11-13', 5, '2023-07-19', 1500),
(64, '2d9ecfba', 'Aleem', 2147483647, 213, '2026-11-13', 5, '2023-07-19', 6400),
(65, '96507f25', 'Aleem', 2147483647, 213, '2026-11-13', 5, '2023-10-02', 1500),
(66, '5308aa06', 'Aleem', 2147483647, 213, '2026-11-13', 5, '2023-10-13', 10000),
(67, 'b1573be0', 'Aleem', 2147483647, 213, '2026-11-13', 5, '2023-10-13', 10000),
(68, '2d63e439', 'Aleem', 2147483647, 213, '2026-11-13', 5, '2023-10-14', 24000),
(69, '36e57619', 'Bhavya', 2147483647, 546, '2026-11-13', 5, '2023-10-14', 10000),
(70, 'af7a71f5', 'Aleem', 2147483647, 213, '2026-11-13', 5, '2023-10-14', 10000),
(71, '1bbad0bc', 'Aleem', 2147483647, 213, '2026-11-13', 5, '2023-10-16', 20000),
(72, '1a248666', 'Aleem', 2147483647, 213, '2027-05-01', 28, '2023-10-16', 20000),
(73, '979c9f04', 'Aleem', 2147483647, 897, '2027-05-01', 28, '2023-10-16', 20000),
(74, '0f663361', 'Aleem', 2147483647, 213, '2026-11-13', 5, '2023-10-17', 17000),
(75, '2fe67ca2', 'Aleem', 2147483647, 213, '2026-11-13', 5, '2023-10-17', 8500),
(76, '820709f1', 'Aleem', 2147483647, 213, '2026-11-13', 5, '2023-10-17', 8500),
(77, '0ce5ddef', 'Aleem', 2147483647, 213, '2026-11-13', 5, '2023-10-17', 8500),
(78, '76306677', 'Aleem', 2147483647, 213, '2026-11-13', 5, '2023-10-17', 20000),
(79, '1cf284f9', 'Aleem', 2147483647, 897, '2027-05-01', 28, '2023-10-17', 20000),
(80, 'c4450ea1', 'Aleem', 2147483647, 897, '2027-05-01', 28, '2023-10-17', 20000),
(81, '4b3a61d8', 'Aleem', 2147483647, 213, '2026-11-13', 5, '2023-10-17', 5000),
(82, 'c103f55e', 'Aleem', 2147483647, 213, '2026-11-13', 5, '2023-10-17', 10000),
(83, '2e38cbb2', 'Aleem', 2147483647, 213, '2026-11-13', 5, '2023-10-17', 24000);

-- --------------------------------------------------------

--
-- Table structure for table `product`
--

CREATE TABLE IF NOT EXISTS `product` (
  `id` int(10) NOT NULL AUTO_INCREMENT,
  `productkey` char(8) NOT NULL,
  `category` varchar(20) NOT NULL,
  `name` varchar(20) NOT NULL,
  `image` text NOT NULL,
  `details` varchar(60) NOT NULL,
  `rentamt` int(7) NOT NULL,
  `amount` int(7) NOT NULL,
  `loginid` int(11) NOT NULL,
  `selling` varchar(10) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=27 ;

--
-- Dumping data for table `product`
--

INSERT INTO `product` (`id`, `productkey`, `category`, `name`, `image`, `details`, `rentamt`, `amount`, `loginid`, `selling`) VALUES
(19, '821b247a', 'Dress', 'Lehenga', '4_25cd88b6-93d3-48c6-96e1-3ded18dea028_1400x.webp', 'Premium Quality', 400, 10000, 28, 'Both'),
(20, '9c784e23', 'Dress', 'Lehenga', '97711.jpg', 'Premium Material', 0, 5000, 28, 'Sell'),
(22, 'abe78cbf', 'Dress', 'saree', '712be6518523314a423b13a5bd235d77.jpg', 'Kanchipuram', 1555, 12000, 28, 'Both'),
(23, '82a4d518', 'Dress', 'saree', 'images (1).jfif', 'Premium Quality Material with premium facilities', 0, 10000, 28, 'Sell'),
(24, '54b0b0f7', 'Dress', 'Lehenga', 'katrina-kaif-wedding-half-saree-682x1024.png', 'Quality Assured', 520, 8500, 28, 'Both'),
(25, '68cf1217', 'Dress', 'Krurta', 'grey-cotton-mens-kurta-pajama-nmk-6148.png', 'Kurta for men', 0, 5000, 27, 'Sell'),
(26, '46eb12f0', 'Dress', 'Kurta', 'ivory-kurta-set-menswear-731_1200x1200.png', 'Premium Quality Product for men', 520, 2500, 27, 'Both');

-- --------------------------------------------------------

--
-- Table structure for table `product_return`
--

CREATE TABLE IF NOT EXISTS `product_return` (
  `id` int(10) NOT NULL AUTO_INCREMENT,
  `returnkey` char(8) NOT NULL,
  `reason` varchar(60) NOT NULL,
  `cartid` int(11) NOT NULL,
  `loginid` int(11) NOT NULL,
  `date` date NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=11 ;

--
-- Dumping data for table `product_return`
--

INSERT INTO `product_return` (`id`, `returnkey`, `reason`, `cartid`, `loginid`, `date`) VALUES
(1, '5ca9ecd4', 'gjj', 25, 1, '2023-05-20'),
(3, 'ba54c82b', 'haha', 40, 5, '2023-07-08'),
(4, 'cd850e62', 'BAD PRODUCT', 44, 5, '2023-07-08'),
(5, 'd8eaeeb8', 'aa', 39, 5, '2023-07-08'),
(6, '89b572c6', 'aa', 39, 5, '2023-07-08'),
(7, '8b00640b', 'damaged', 59, 5, '2023-10-13'),
(8, '1b5947d0', 'bad product', 67, 5, '2023-10-16'),
(9, '46783179', 'a', 70, 5, '2023-10-17'),
(10, 'b9a5768b', 'i did not like it', 70, 5, '2023-10-17');

-- --------------------------------------------------------

--
-- Table structure for table `rentdtl`
--

CREATE TABLE IF NOT EXISTS `rentdtl` (
  `id` int(10) NOT NULL AUTO_INCREMENT,
  `rentkey` char(8) NOT NULL,
  `days` int(5) NOT NULL,
  `address` varchar(60) NOT NULL,
  `quantity` int(5) NOT NULL,
  `productid` int(11) NOT NULL,
  `currentdate` date NOT NULL,
  `loginid` int(11) NOT NULL,
  `amount` int(7) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=59 ;

--
-- Dumping data for table `rentdtl`
--

INSERT INTO `rentdtl` (`id`, `rentkey`, `days`, `address`, `quantity`, `productid`, `currentdate`, `loginid`, `amount`) VALUES
(8, '3406ef95', 6, 'anu bhavan', 4, 14, '2023-04-17', 5, 12480),
(9, '721521bd', 0, '', 5, 12, '2023-04-19', 12, 600000),
(10, '01525ce2', 0, '', 4, 12, '2023-04-19', 12, 480000),
(11, 'e2f0aada', 0, '', 2, 12, '2023-04-19', 12, 240000),
(12, 'fe39f1a6', 0, '', 1, 12, '2023-04-20', 5, 120000),
(13, '17c17777', 0, '', 4, 12, '2023-04-20', 5, 480000),
(14, 'c8e884e2', 0, '', 3, 12, '2023-04-21', 5, 360000),
(15, 'a833c344', 0, '', 2, 12, '2023-04-21', 5, 240000),
(16, 'bc07b0f4', 0, '', 2, 12, '2023-04-21', 5, 240000),
(17, '5166f2ec', 0, '', 4, 12, '2023-04-21', 5, 480000),
(18, '7ff1d85c', 0, '', 4, 12, '2023-04-21', 5, 480000),
(19, 'a56992b7', 0, '', 4, 12, '2023-04-21', 5, 480000),
(20, 'f9dd648f', 0, '', 1, 12, '2023-04-21', 5, 120000),
(21, '3ed5c6a8', 0, '', 2, 12, '2023-04-26', 5, 240000),
(22, '27fe47b8', 0, '', 3, 12, '2023-04-26', 5, 360000),
(23, '6a2a2e93', 0, '', 3, 12, '2023-04-26', 5, 360000),
(24, 'a84bc216', 0, '', 3, 12, '2023-04-26', 5, 360000),
(25, 'bc268d02', 0, '', 3, 12, '2023-04-26', 5, 360000),
(26, 'c8e37f09', 0, '', 3, 12, '2023-04-26', 5, 360000),
(27, 'e9c5e239', 0, '', 3, 12, '2023-04-26', 5, 360000),
(28, '3dd57149', 0, '', 2, 12, '2023-04-26', 5, 240000),
(29, '02b0b759', 0, '', 3, 12, '2023-04-26', 5, 360000),
(30, '2d822843', 0, '', 3, 12, '2023-04-26', 5, 360000),
(31, '202406f1', 0, '', 3, 12, '2023-04-26', 5, 360000),
(32, 'fca98a21', 0, '', 4, 12, '2023-04-26', 5, 480000),
(33, 'c3a383bc', 0, '', 1, 12, '2023-04-26', 5, 120000),
(34, '3ee07037', 0, '', 1, 12, '2023-04-26', 5, 120000),
(35, 'b219e5c7', 0, '', 1, 12, '2023-04-26', 5, 120000),
(36, 'a0369bf8', 0, '', 4, 12, '2023-04-26', 5, 480000),
(37, '809431d0', 0, '', 7, 12, '2023-04-26', 5, 840000),
(38, 'b2e85092', 0, '', 2, 12, '2023-04-26', 5, 240000),
(39, '3443a585', 0, '', 1, 12, '2023-04-26', 5, 120000),
(40, '9e62235e', 0, '', 1, 12, '2023-04-26', 5, 120000),
(41, '261890dc', 0, '', 2, 11, '2023-04-26', 5, 1500),
(42, '17de9064', 0, '', 3, 13, '2023-04-26', 5, 3000),
(43, 'a9319931', 0, '', 1, 15, '2023-04-26', 9, 3200),
(44, '091e91c6', 0, '', 3, 12, '2023-04-26', 9, 360000),
(45, 'd565662a', 0, '', 2, 15, '2023-04-26', 9, 6400),
(46, 'd0458546', 0, '', 4, 11, '2023-04-27', 5, 3000),
(47, '2410ba39', 0, '', 3, 11, '2023-04-27', 5, 2250),
(48, '4abab0dd', 0, '', 2, 15, '2023-04-27', 5, 6400),
(49, 'adbe2414', 0, '', 3, 11, '2023-04-27', 5, 2250),
(50, '0c20f5ca', 0, '', 2, 11, '2023-04-27', 5, 1500),
(51, 'ffad95a8', 0, '', 2, 11, '2023-04-27', 5, 1500),
(52, '312c2a35', 0, '', 3, 11, '2023-05-06', 5, 2250),
(53, '310ee218', 5, 'aaa', 55, 11, '2023-05-13', 5, 143000),
(54, '4eba0630', 2, 'cgj', 3, 14, '2023-07-08', 5, 3120),
(55, 'd3be8b92', 2, 'cgj', 3, 14, '2023-07-08', 5, 3120),
(56, '3685e9f6', 2, 'cgj', 3, 14, '2023-07-08', 5, 3120),
(57, 'd7010d8c', 2, 'cgj', 3, 14, '2023-07-08', 5, 3120),
(58, '9d3bfbc3', 2, 'a', 2, 15, '2023-10-02', 5, 800);

-- --------------------------------------------------------

--
-- Table structure for table `shop`
--

CREATE TABLE IF NOT EXISTS `shop` (
  `id` int(10) NOT NULL AUTO_INCREMENT,
  `eventkey` char(8) NOT NULL,
  `name` varchar(20) NOT NULL,
  `image` text NOT NULL,
  `address` varchar(60) NOT NULL,
  `pincode` varchar(6) NOT NULL,
  `dist` varchar(20) NOT NULL,
  `city` varchar(20) NOT NULL,
  `contact` varchar(12) NOT NULL,
  `registration` int(5) NOT NULL,
  `loginid` int(11) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=18 ;

--
-- Dumping data for table `shop`
--

INSERT INTO `shop` (`id`, `eventkey`, `name`, `image`, `address`, `pincode`, `dist`, `city`, `contact`, `registration`, `loginid`) VALUES
(12, '2214c043', 'Variety', 'About_Us.jpg', 'Variety Punaloor', '698504', 'Kollam', 'Punaloor', '0906785435', 255, 27),
(13, '30e4d5d9', 'F2fashion', 'images.jfif', 'F2fashion,Kilimanoor', '695609', 'Trivandrum', 'Kilimanoor', '8589917005', 256, 28),
(14, 'fc636b49', 't20', 'About_Us.jpg', 'T20 Kallara', '695608', 'Trivandrum', 'Kallara', '9858645785', 2557, 29),
(15, '5bdc4d4b', 'Allen solly', 'images.jfif', 'Kallar', '858965', 'Trivandrum', 'Kallara', '9885565142', 2558, 32),
(16, 'cba1c18d', 't20', 'images.jfif', 't20,puliyoorkonam p.o,kilimanoor', '696604', 'Alappuzha', 'Punaloor', '7736156224', 2256, 35);

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
